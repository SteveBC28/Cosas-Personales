###  Áreas Principales del Plan de Estudios
Un currículo estándar se divide en las siguientes áreas fundamentales: 

·Inteligencia Artificial e Ingeniería del Software
Ciencias Básicas y Matemáticas: Cálculo diferencial e integral, álgebra lineal, probabilidad y estadística, y matemáticas discretas. Proporcionan el razonamiento lógico para resolver problemas complejos. 

### Universidad Internacional de las Américas, UIA
 
Fundamentos de Computación: Introducción a la programación, estructuras de datos y algoritmos, arquitecturas de computadores y sistemas operativos. 

Universidad Internacional de las Américas, UIA
 
Desarrollo de Software: Programación avanzada (orientada a objetos), diseño de bases de datos, desarrollo web y aplicaciones para dispositivos móviles. 

HubSpot
 
Ingeniería y Calidad: Análisis y especificación de requisitos, arquitectura de software, pruebas, aseguramiento de la calidad y gestión de proyectos.

### Estructura Semestral Típica

Primeros Semestres (Bases y Ciencias)
Matemáticas básicas y Cálculo I y II
Introduccion a la computacion y logica de programacion
Estructuras discretas y álgebra lineal
Arquitectura y organizacion de computadoras 

Corporación Universitaria Empresarial Alexander Von Humboldt
 
Semestres Intermedios (Core Técnico)
Programación avanzada (I, II, III)
Estructuras de datos y algoritmos complejos.
Bases de datos relacionales y no relacionales
Redes de computadores y sistemas operativos
Ingeniería de software I y II (metodologías de desarrollo y modelado UML) 

Corporación Universitaria Empresarial Alexander Von Humboldt
 
Semestres Avanzados (Especialización y Gestión)
Arquitectura de software aplicada
Desarrollo web avanzado y aplicaciones móviles
Calidad y pruebas de software
Gestión de proyectos y ética profesional.
Práctica profesional o proyecto de graduación (Tesis / Capstone)