Lo que harás:

- Desarrollar y mantener aplicaciones Python, enfocándote en escribir código limpio, eficiente y bien documentado.
- Colaborar con equipos de desarrollo en diversos proyectos, contribuyendo a diferentes etapas del ciclo de vida del desarrollo de software.
- Identificar y solucionar errores de software, participando en la implementación de soluciones y optimizaciones.
- Participar en revisiones de código, tanto revisando el de otros como haciendo que revisen el tuyo, para mantener una alta calidad de software y aprender mejores prácticas.
- Mantenerte actualizado con nuevos frameworks y bibliotecas de Python. Aplicar estas tecnologías de manera efectiva en proyectos nuevos y existentes.
- Participar activamente en reuniones y discusiones de equipo, contribuyendo con ideas y comentarios para mejorar el desarrollo del proyecto.

Lo que Buscamos:

- 1 año de experiencia con Python.
- Buen conocimiento de algoritmos básicos y estructuras de datos.
- Conocimiento básico de sistemas de control de versiones, preferiblemente Git.
- Capacidad para resolver problemas de manera efectiva y aprender nuevas tecnologías rápidamente.
- Buen nivel de inglés.

Qué ofrecemos para que tu trabajo (y tu vida) sea más fácil:

- Trabajo 100% remoto: trabaja desde tu casa o donde quieras.
- Compensación en USD o en tu moneda local, como prefieras, muy por encima de la media del mercado.
- Hardware y software.
- Horarios flexibles
- Licencias por mater/paternidad, vacaciones y días festivos nacionales pagos.
- Ambiente laboral multicultural e innovador, perfecto para hacer amigos, colaborar y aprender de las personas más talentosas del mundo.
- Oportunidades de crecimiento y desarrollo profesional a través de mentorías y entrenamientos.